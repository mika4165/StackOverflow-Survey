# Data Cleaning Log
## Study: Trust and Ethical Concerns about Workplace AI: Evidence from Developer Survey Data

### 1. Source files and provenance
- **Dataset:** Stack Overflow Developer Survey 2026, Stack Exchange, Inc.
- **Source page:** https://survey.stackoverflow.co/2026
- **AI Trust data page:** https://survey.stackoverflow.co/2026/ai/data/ai-trust
- **Files supplied for this workflow:** `survey_results_public.csv` and `survey_results_schema.csv`.
- **Proposal's stated collection/download date:** October 14, 2026.
- **Raw data dimensions observed:** 30,903 rows × 212 columns.
- **Schema dimensions observed:** 212 rows × 10 columns.
- **Codebook AITrust non-missing count:** 14,304.

### 2. Study alignment and variable decisions
The proposal's research questions concern (RQ1) trust in AI output and verification; (RQ2) ethical issues developers report; and (RQ3) workplace AI policies and legal/policy views.

The supplied CSV/codebook were inspected before variable selection. The actual fields used are:
- `AITrust`: primary trust outcome; 14,304 non-missing responses.
- `AIWorkNext`: actions taken before using an AI-generated answer for a development task (multi-select).
- `AIAvoid`: selected reason for avoiding AI at work or school; includes moral/ethical and privacy/security categories.
- `AIAdopt`: up to three adoption considerations; includes accuracy, security/privacy, legal/compliance, and company-policy answer options.
- `AIUse`: description of how AI tools/agents are used at the respondent's organization.
- `AISelect`, `Age`, `Country`, `Education`, `YearsCode`, `WorkExp`, `Role`, and `OrgSize`: supporting usage and respondent descriptors.

**Important codebook reconciliation:** The proposal refers to `AIAcc`, `YearsCodePro`, and `AIWorkTask`, but these exact columns are not present in the supplied public CSV. The notebook does not invent substitutes. It uses `AITrust`, `AIWorkNext`, `YearsCode`, and `WorkExp` where appropriate. The codebook has no single comprehensive `EthicalConcern` field; `AIAvoid` and `AIAdopt` are treated as limited indicators, not as a validated ethics scale.

### 3. Cleaning operations
| Step | Operation | Rationale / treatment |
|---|---|---|
| 1 | Read original public CSV and schema CSV without modifying source files | Preserve raw data and maintain provenance |
| 2 | Validate `ResponseId` is non-null and unique | Check respondent-key integrity before processing |
| 3 | Select relevant research variables and supporting descriptors | Keep analysis focused and reduce unnecessary handling |
| 4 | Trim leading/trailing whitespace in text fields | Normalize accidental whitespace without changing response labels |
| 5 | Convert empty strings to missing values | Treat blank strings consistently as unanswered |
| 6 | Preserve categorical labels, including “Not sure”, “Not applicable”, and “I don't use AI” | These are substantive answers, not generic missing values |
| 7 | Preserve semicolon-separated multi-select responses | Retain original answers; derive explicit binary indicators for selected `AIAdopt` options only |
| 8 | Define primary sample as records with non-missing `AITrust` | Align primary analysis to the study's trust outcome; expected n = 14,304 |
| 9 | Retain missing values in secondary variables; no imputation | Avoid inventing responses; account for skip logic and item non-response |
| 10 | Drop `ResponseId` from analysis exports | Reduce linkage/re-identification risk |

### 4. Files produced by the notebook
Running `workplace_AI_trust_cleaning_analysis.ipynb` creates an `outputs/` directory containing:
- `cleaned_relevant_survey_extract.csv` — selected variables for all survey respondents.
- `cleaned_AITrust_analysis_sample.csv` — primary sample with a recorded `AITrust` response.
- `AITrust_distribution.csv`
- `verification_actions.csv`
- `AI_avoidance_reasons.csv`
- `AI_adoption_factors.csv`
- `organizational_AI_use.csv`
- `AITrust_by_organizational_AI_use.csv`

The analysis exports omit `ResponseId`. The raw source CSVs are not overwritten.

### 5. Missing data and sample definition
The supplied public file contains 30,903 respondent records. `AITrust` has 14,304 non-missing answers and 16,599 missing values. Missing values are not interpreted as distrust, non-use, or absence of ethical concern. Other AI module items have different non-missing counts because of question routing, skip logic, and non-response. Each table therefore uses its own answered-item denominator and should report that denominator.

### 6. Known limitations and cautions
- The proposal identifies voluntary opt-in sampling bias and possible skew toward active, English-speaking web developers.
- All relevant attitudes and practices are self-reported.
- `AIAvoid` is a single selected reason and does not capture every ethical concern a respondent may hold.
- `AIAdopt` is a multi-select decision-factor question, not a direct measurement of law awareness or policy effectiveness.
- `AIUse` describes organizational use patterns; it does not prove that an organization has a formal AI policy.
- The data support descriptive summaries and cross-tabulations, not causal claims.
- No respondent re-identification or linkage to external profiles is permitted.

### 7. Reproduction instructions
1. Place `workplace_AI_trust_cleaning_analysis.ipynb`, `survey_results_public.csv`, and `survey_results_schema.csv` in the same directory.
2. Install dependencies: `pip install pandas numpy matplotlib`.
3. Open the notebook in Jupyter Notebook, JupyterLab, or Google Colab (upload both CSVs if using Colab).
4. Run all cells from top to bottom.
5. Review the printed counts and `outputs/` files. The notebook will stop with an explicit error if the required source files or expected columns are missing.

### 8. Audit note
This log records operations implemented in the accompanying notebook. It does not claim that the survey's original collection process, sampling design, or source data were independently audited.
